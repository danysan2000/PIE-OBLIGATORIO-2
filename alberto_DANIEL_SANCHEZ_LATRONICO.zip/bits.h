/* 
bits.h
*/

int             bit(unsigned int buffer, int nb);
int             ver_binario(unsigned int buffer, int nb, FILE* nombreArchivo);
void            print_binario(unsigned int buffer, int nb);
unsigned int    setbit(unsigned int buffer, int nb, int val);
unsigned int    concatena(unsigned int buffer, unsigned int codigo, int nb);
unsigned int    crear_mascara(int max, int min);
unsigned int    espejar(unsigned int in, int nbits);
unsigned int    extraer(unsigned int buffer, int min, int max);


